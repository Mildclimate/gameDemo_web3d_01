<template>
  <section class="game-viewport" aria-label="3D 游戏渲染区域">
    <div class="game-viewport__grid" aria-hidden="true"></div>
    <div class="game-viewport__vignette" aria-hidden="true"></div>

    <p class="game-viewport__label">
      <span class="game-viewport__title">3D Viewport</span>
      <span class="game-viewport__hint">Three.js 场景将在 M1 接入</span>
    </p>

    <span class="game-viewport__corner game-viewport__corner--tl" aria-hidden="true"></span>
    <span class="game-viewport__corner game-viewport__corner--tr" aria-hidden="true"></span>
    <span class="game-viewport__corner game-viewport__corner--bl" aria-hidden="true"></span>
    <span class="game-viewport__corner game-viewport__corner--br" aria-hidden="true"></span>
  </section>
</template>

<style scoped>
.game-viewport {
  position: absolute;
  inset: 0;
  display: grid;
  place-items: center;
  overflow: hidden;
  background:
    radial-gradient(circle at 50% 55%, rgba(38, 118, 168, 0.22), transparent 62%),
    linear-gradient(180deg, #050a14 0%, #02040a 100%);
}

.game-viewport__grid {
  position: absolute;
  inset: 0;
  background-image:
    linear-gradient(rgba(95, 230, 255, 0.06) 1px, transparent 1px),
    linear-gradient(90deg, rgba(95, 230, 255, 0.06) 1px, transparent 1px);
  background-size: 64px 64px;
  mask-image: radial-gradient(circle at 50% 50%, #000 20%, transparent 78%);
}

.game-viewport__vignette {
  position: absolute;
  inset: 0;
  background: radial-gradient(circle at 50% 50%, transparent 45%, rgba(1, 3, 8, 0.85) 100%);
}

.game-viewport__label {
  position: relative;
  display: grid;
  gap: 8px;
  padding: 0 24px;
  text-align: center;
}

.game-viewport__title {
  font-size: clamp(0.85rem, 1.4vw, 1.05rem);
  font-weight: 600;
  letter-spacing: 0.32em;
  text-transform: uppercase;
  color: var(--color-accent);
  opacity: 0.75;
}

.game-viewport__hint {
  font-size: clamp(0.72rem, 1.1vw, 0.82rem);
  letter-spacing: 0.08em;
  color: var(--color-text-muted);
}

.game-viewport__corner {
  position: absolute;
  width: 22px;
  height: 22px;
  border: 1px solid var(--color-border-strong);
  opacity: 0.7;
}

.game-viewport__corner--tl {
  top: 18px;
  left: 18px;
  border-right: none;
  border-bottom: none;
}

.game-viewport__corner--tr {
  top: 18px;
  right: 18px;
  border-left: none;
  border-bottom: none;
}

.game-viewport__corner--bl {
  bottom: 18px;
  left: 18px;
  border-top: none;
  border-right: none;
}

.game-viewport__corner--br {
  right: 18px;
  bottom: 18px;
  border-top: none;
  border-left: none;
}
</style>
