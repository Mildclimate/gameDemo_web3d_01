# ASTRA: Lost Relic

基于 Vue 3 + TypeScript + Three.js 的 Web 3D 探索收集小游戏。当前完成 **M0：工程骨架**，3D 场景尚未接入。

## 技术栈

- Vue 3（Composition API + `<script setup>`）
- TypeScript（严格模式）
- Vite
- ESLint 9 + Prettier

## 环境要求

- Node.js >= 20.19
- npm >= 10

## 常用命令

| 命令                   | 说明                              |
| ---------------------- | --------------------------------- |
| `npm install`          | 安装依赖                          |
| `npm run dev`          | 启动开发服务器                    |
| `npm run build`        | 类型检查并生成生产构建（`dist/`） |
| `npm run preview`      | 本地预览生产构建                  |
| `npm run typecheck`    | 执行 `vue-tsc` 类型检查           |
| `npm run lint`         | ESLint 检查                       |
| `npm run lint:fix`     | ESLint 自动修复                   |
| `npm run format`       | Prettier 格式化                   |
| `npm run format:check` | Prettier 格式校验                 |

## 目录结构

```text
.
├── src/
│   ├── components/
│   │   ├── GameMenu.vue       # 游戏大厅 UI 占位
│   │   └── GameViewport.vue   # 3D 渲染区域容器
│   ├── styles/main.css        # 全局设计变量与基础样式
│   ├── App.vue                # 页面布局：画布区域 + UI overlay
│   └── main.ts
├── index.html
├── env.d.ts
├── eslint.config.js
├── .prettierrc.json
├── vite.config.ts
├── tsconfig.json
├── plan_game.md               # 项目开发规范
└── README.md
```

后续按里程碑补充 `public/assets`、`game/core`、`game/scene`、`types`、`services` 等目录，不预先创建空文件。

## 架构约定

- **Vue 层**：页面布局、菜单、HUD、弹窗、加载/错误状态和低频业务状态。
- **Three.js Runtime 层**：Scene、Camera、Renderer、渲染循环、资源生命周期（M1 起建立）。
- 两层通过明确的 TypeScript command/event 接口通信；每帧高频数据不写入 Vue 响应式状态。

## 里程碑状态

| 里程碑 | 内容             | 状态   |
| ------ | ---------------- | ------ |
| M0     | 工程骨架         | 完成   |
| M1     | Three.js Runtime | 待开始 |
| M2     | 玩家移动与摄像机 | 待开始 |
| M3     | 玩法闭环         | 待开始 |
| M4     | UI 与移动端      | 待开始 |
| M5     | 资产接入         | 待开始 |
| M6     | 性能、清理与测试 | 待开始 |
| M7     | 部署与交付       | 待开始 |

## 已知限制

- 尚未接入 Three.js，页面只包含画布容器与 UI 占位。
- 尚未配置 `npm run test`：M0 没有可测试的纯逻辑，测试框架将在引入状态机/规则逻辑（M3）时加入。
- 未初始化 Git 仓库。
